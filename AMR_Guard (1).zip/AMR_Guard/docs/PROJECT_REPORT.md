# AMR-Guard: An AI-Based Antibiotic Stewardship Assistant
### Project Report — Theme: Combating Antimicrobial Resistance (Swasth Bharat)

**Team members:** ______________________  **Department:** B.Pharm, 1st Year
**Institution:** ______________________  **Date:** ____________

---

## 1. Abstract
Antimicrobial resistance (AMR) makes common infections harder to treat. A key driver is
*empirical* prescribing — choosing an antibiotic before the culture report (48–72 hours)
is available, often defaulting to broad-spectrum "Watch" or "Reserve" drugs. AMR-Guard is a
machine-learning prototype that predicts, from routine patient information, the probability that
each antibiotic will work, and then recommends the narrowest effective option using the WHO
AWaRe classification. Trained on 6,000 synthetic culture records, the models achieve ROC-AUC
values of roughly 0.67–0.77 for most antibiotics. The system is delivered as an interactive web
application with a surveillance dashboard and a downloadable stewardship report.

## 2. Problem statement
- AMR is recognised by WHO as a major global public health threat, and India carries a high
  burden, with high resistance to commonly used antibiotics reported by national surveillance
  networks.
- Culture and sensitivity reports take 2–3 days; treatment decisions cannot wait.
- Without data, prescribers tend to choose powerful broad-spectrum antibiotics "to be safe",
  which in turn creates more resistance — a vicious cycle.
- Pharmacists in antimicrobial stewardship programmes need quick, data-driven support to review
  such prescriptions.

## 3. Objectives
1. Predict the chance of resistance for 10 antibiotics across 4 common bacteria.
2. Recommend the narrowest safe antibiotic (Access before Watch before Reserve).
3. Flag high-risk patients where no option is reliably effective.
4. Visualise local resistance patterns (antibiogram dashboard) for public-health awareness.

## 4. Scope
| Item | Covered |
|---|---|
| Organisms | *E. coli, K. pneumoniae, P. aeruginosa, S. aureus* |
| Specimens | Urine, Blood, Sputum, Wound/Pus |
| Antibiotics | Amoxicillin-clavulanate, Gentamicin, Nitrofurantoin, Co-trimoxazole (Access); Ciprofloxacin, Ceftriaxone, Meropenem, Vancomycin (Watch); Linezolid, Colistin (Reserve) |
| Inputs | Organism, specimen, care setting, age, gender, prior antibiotics (90 d), recent hospitalisation, urinary catheter, diabetes |

## 5. Methodology

### 5.1 Data
Real patient records are confidential, so a **synthetic dataset** of 6,000 isolates was
generated (`generate_data.py`). Baseline resistance rates for each bug–drug pair are
illustrative values loosely inspired by published Indian surveillance trends. Known risk factors
raise the probability of resistance: ICU stay, hospital ward stay, antibiotics in the last 90
days, recent hospitalisation, urinary catheter, age ≥ 65 and diabetes. A hidden random
"multi-drug resistance" factor adds realistic unpredictability. Drugs that do not act on an
organism (e.g. vancomycin on Gram-negatives) or are unsuitable for a specimen (nitrofurantoin
outside urine) are marked *not applicable*.

### 5.2 Model
For each antibiotic a separate binary classifier is trained (Resistant vs Susceptible):
- Text inputs (organism, specimen, setting, gender) are converted to numbers with **one-hot encoding**.
- Two algorithms are compared: **Logistic Regression** and **Random Forest** (200 trees).
- Data is split 75% training / 25% testing; the algorithm with the higher **ROC-AUC** is kept
  and retrained on all data.

### 5.3 Stewardship decision rule
1. Keep antibiotics with predicted chance of working ≥ 80%.
2. Sort by AWaRe group (Access → Watch → Reserve), then by chance of working.
3. Recommend the first one; show the next two as alternatives.
4. If none reach 80%, raise a high-risk alert and advise specialist referral.

### 5.4 System architecture
```
Patient & culture details (web form)
            │
            ▼
  Pre-processing (one-hot encoding)
            │
            ▼
  10 AI models (one per antibiotic)  ──►  chance of working (%)
            │
            ▼
  AWaRe stewardship rule  ──►  Recommendation + alternatives / alert
            │
            ▼
  Web app: predicted antibiogram, charts, downloadable report
```

## 6. Results
Model performance on held-out test data (values from our run; yours will be identical because a
fixed random seed is used):

| Antibiotic | AWaRe | Best model | ROC-AUC | % Resistant |
|---|---|---|---|---|
| Amoxicillin-clavulanate | Access | Logistic Regression | 0.69 | 59.4 |
| Gentamicin | Access | Logistic Regression | 0.73 | 38.0 |
| Nitrofurantoin | Access | Random Forest | 0.67 | 18.6 |
| Co-trimoxazole | Access | Logistic Regression | 0.72 | 50.6 |
| Ciprofloxacin | Watch | Logistic Regression | 0.70 | 60.9 |
| Ceftriaxone | Watch | Random Forest | 0.68 | 64.2 |
| Meropenem | Watch | Logistic Regression | 0.77 | 27.5 |
| Vancomycin | Watch | Logistic Regression | 0.52 | 1.1 |
| Linezolid | Reserve | Logistic Regression | 0.73 | 1.2 |
| Colistin | Reserve | Logistic Regression | 0.74 | 6.4 |

**Interpretation:** most models are clearly better than guessing (0.5). Vancomycin resistance is
so rare (~1%) that there are too few examples to learn from — an honest limitation.

**Case studies**
- *Young woman, community UTI, E. coli, no risk factors* → Nitrofurantoin (Access), ~92%.
  Meropenem and colistin would also work, but the tool avoids them — protecting last-resort drugs.
- *70-year-old ICU patient, Klebsiella in blood, all risk factors* → no drug reaches 80%;
  even colistin ~55%. The tool raises an alert, demonstrating the real-world danger of AMR.

## 7. Impact & relevance to pharmacy
- Supports **antimicrobial stewardship programmes**, where pharmacists review antibiotic use.
- Aligns with India's **National Action Plan on AMR** and the WHO **AWaRe** framework.
- Dashboard supports **public-health surveillance** and hospital antibiogram awareness.
- Educational use: teaches students how risk factors drive resistance.

## 8. Limitations
- Trained on synthetic data; must be validated on real hospital data before any clinical use.
- Does not consider infection severity, allergies, kidney function, pregnancy or drug interactions.
- Limited to 4 organisms and 10 antibiotics.
- Assumes the organism is already identified (in reality this may also take time).

## 9. Future scope
- Train on real, anonymised hospital antibiogram data (with ethics approval).
- Add allergy, renal-dose and drug-interaction checks.
- Hindi / regional-language interface and mobile app for rural clinics.
- Explainable AI showing which risk factor contributed most to each prediction.
- Integration with hospital information systems and national AMR surveillance.

## 10. Tools & technologies
Python 3, pandas, NumPy, scikit-learn, Streamlit, joblib, VS Code.

## 11. References
1. World Health Organization. *Global Action Plan on Antimicrobial Resistance*, 2015.
2. World Health Organization. *The WHO AWaRe (Access, Watch, Reserve) Antibiotic Book*, 2022.
3. Government of India. *National Action Plan on Antimicrobial Resistance (NAP-AMR) 2017–2021*.
4. Indian Council of Medical Research. *Antimicrobial Resistance Research & Surveillance Network — Annual Reports*.
5. Pedregosa F. et al. *Scikit-learn: Machine Learning in Python*. JMLR 12, 2011.
