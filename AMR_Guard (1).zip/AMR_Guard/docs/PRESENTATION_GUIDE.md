# 7-Minute Presentation Script + 3-Minute Q&A Prep

## Timing plan (7 min)

| Time | Section | Speaker |
|---|---|---|
| 0:00–1:00 | The problem (hook) | Member 1 |
| 1:00–2:00 | Our idea + AWaRe | Member 2 |
| 2:00–5:00 | **LIVE DEMO** | Member 3 |
| 5:00–6:15 | How the AI works + results | Member 4 |
| 6:15–7:00 | Impact, limitations, future | Member 1 |

(Working alone? Same order, just you.)

## Script

**1. Hook (1 min)**
"A patient arrives with a fever and infection. The lab report will take three days. The doctor
has to choose an antibiotic *now*. If it's the wrong one, treatment fails. If it's always the
strongest one, bacteria learn to resist it — and one day nothing works. That is Antimicrobial
Resistance, and India is among the hardest-hit countries."

**2. Our idea (1 min)**
"AMR-Guard is an AI assistant for doctors and stewardship pharmacists. It predicts which
antibiotics will likely work, then follows the WHO AWaRe rule: use Access drugs first, Watch
carefully, and protect Reserve drugs."

**3. Live demo (3 min)** — have the app already open!
1. *Patient A:* E. coli, Urine, Community, 28 F, no risk factors → point at the green card:
   Nitrofurantoin. "Meropenem also works at 93% — but using it here would waste a precious drug.
   AMR-Guard picks the simplest one that works."
2. Tick "Antibiotics in last 90 days" and change setting to ICU → watch percentages fall live.
   "Every risk factor increases resistance."
3. *Patient B:* Klebsiella, Blood, ICU, 70 M, all boxes ticked → purple alert.
   "Even colistin, our last-resort drug, is uncertain. This is what AMR looks like."
4. Click **Download report**. Open **Dashboard** tab: "Resistance climbs from community to ICU."

**4. How it works (1¼ min)**
"We built 6,000 culture records. For each of 10 antibiotics we trained two algorithms —
Logistic Regression and Random Forest — and kept the better one. Most models score around 0.7
ROC-AUC, meaning they rank risk clearly better than chance."

**5. Close (¾ min)**
"This is a prototype on synthetic data — the next step is real hospital data with ethics
approval, plus allergy and kidney-dose checks, and a Hindi mobile version for rural clinics.
AMR-Guard helps save today's patient *and* tomorrow's antibiotics. Thank you."

## Likely judge questions & answers

**Q: Why synthetic data?**
Real patient data is confidential and needs ethics approval. We designed synthetic data using
known risk patterns so the pipeline is ready; plugging in real data needs only a new CSV.

**Q: How accurate is it?**
ROC-AUC ≈ 0.67–0.77 for most drugs. That's decision *support* — it improves the guess before the
lab report, it doesn't replace the lab report or the doctor.

**Q: What is ROC-AUC?**
If you take one resistant and one susceptible case at random, AUC is the chance the model gives
the resistant one a higher risk score. 0.5 = coin toss, 1.0 = perfect.

**Q: Why is vancomycin AUC so low?**
Resistance is only ~1%, so there are very few examples to learn from. We show it honestly
rather than hiding it.

**Q: What is AWaRe?**
A WHO classification: Access (first-line, lower resistance risk), Watch (higher resistance
potential), Reserve (last resort). It guides stewardship.

**Q: Why not just recommend the drug with the highest percentage?**
Because that's usually a Reserve/Watch drug. Overusing it creates resistance to it. Our rule
picks the narrowest drug that is still ≥ 80% likely to work.

**Q: What is the pharmacist's role here?**
Stewardship pharmacists review antibiotic prescriptions, suggest de-escalation, and monitor
drugs like gentamicin and vancomycin. AMR-Guard gives them a fast, data-based second opinion.

**Q: Logistic Regression vs Random Forest?**
Logistic Regression adds up weighted risk factors — simple and explainable. Random Forest is
many decision trees voting. We try both and keep whichever scores better per antibiotic.

**Q: Could this harm patients?**
Only if used alone. It carries a disclaimer, flags high-risk cases for specialist review, and is
meant to be confirmed by culture results.

## Presentation-day checklist
- [ ] Ran `pip install -r requirements.txt` and `python train_model.py` at home
- [ ] App opened and tested on the presentation laptop (works offline)
- [ ] `demo_cli.py` tested as backup; screenshots in a slide as a second backup
- [ ] Laptop charger, display adapter (HDMI)
- [ ] Browser zoom at 125% so judges can read
