"""
generate_data.py  -  Creates a realistic-looking SYNTHETIC dataset of
bacterial culture reports ("isolates").

Why synthetic?  Real hospital data is private.  For a student prototype we
simulate data using known patterns:
  * ICU patients -> more resistance
  * recent antibiotic use -> more resistance
  * catheters / recent hospital stay -> more resistance
Later, you can swap in a real dataset with the same column names.

Run:   python generate_data.py
"""
import os
import numpy as np
import pandas as pd

from config import (ORGANISMS, ORGANISM_PREVALENCE, SPECIMENS, SPECIMEN_BY_ORGANISM,
                    SETTINGS, SETTING_PREVALENCE, ANTIBIOTICS, BASE_RESISTANCE,
                    is_applicable, DATA_PATH)


def _logit(p):
    """Turns a probability (0-1) into log-odds so we can add risk to it."""
    return np.log(p / (1 - p))


def _sigmoid(x):
    """Turns log-odds back into a probability (0-1)."""
    return 1 / (1 + np.exp(-x))


def generate_dataset(n: int = 6000, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)   # seed = same data every run

    # ---- Patient & sample details -------------------------------------
    organism = rng.choice(ORGANISMS, size=n, p=ORGANISM_PREVALENCE)
    specimen = np.array([rng.choice(SPECIMENS, p=SPECIMEN_BY_ORGANISM[o]) for o in organism])
    setting = rng.choice(SETTINGS, size=n, p=SETTING_PREVALENCE)
    s_idx = np.array([SETTINGS.index(s) for s in setting])      # 0, 1, 2

    age = np.clip(rng.normal(48, 20, n), 1, 95).round().astype(int)
    gender = rng.choice(["Male", "Female"], size=n)

    # sicker settings -> more risk factors
    prior_abx = rng.random(n) < np.array([0.30, 0.50, 0.70])[s_idx]
    hospitalized = rng.random(n) < np.array([0.10, 0.40, 0.60])[s_idx]
    catheter = rng.random(n) < np.array([0.05, 0.30, 0.70])[s_idx]
    diabetes = rng.random(n) < (0.10 + 0.25 * (age > 50))

    # ---- Risk score: how much each factor raises resistance -----------
    hidden_mdr = rng.normal(0, 0.7, n)      # unmeasured "multi-drug resistant" tendency
    risk = (0.5 * (s_idx == 1) + 1.0 * (s_idx == 2)
            + 0.8 * prior_abx + 0.6 * hospitalized + 0.4 * catheter
            + 0.3 * (age >= 65) + 0.2 * diabetes + hidden_mdr)
    risk = risk - risk.mean()   # centre it so average rates match BASE_RESISTANCE

    df = pd.DataFrame({
        "isolate_id": [f"ISO{i:05d}" for i in range(1, n + 1)],
        "organism": organism, "specimen": specimen, "setting": setting,
        "age": age, "gender": gender,
        "prior_antibiotics_90d": prior_abx.astype(int),
        "hospitalized_90d": hospitalized.astype(int),
        "urinary_catheter": catheter.astype(int),
        "diabetes": diabetes.astype(int),
    })

    # ---- Resistance result for every antibiotic -----------------------
    # 1 = Resistant, 0 = Susceptible, blank = not tested / not applicable
    for abx in ANTIBIOTICS:
        applicable = np.array([is_applicable(abx, o, s) for o, s in zip(organism, specimen)])
        base = np.array([BASE_RESISTANCE[o].get(abx, 0.5) for o in organism])
        strength = np.where(base < 0.05, 0.5, 1.0)   # rare resistances stay rare
        p_resistant = _sigmoid(_logit(base) + strength * risk)
        result = (rng.random(n) < p_resistant).astype(float)
        result[~applicable] = np.nan
        df[abx] = result

    return df


if __name__ == "__main__":
    os.makedirs("data", exist_ok=True)
    data = generate_dataset()
    data.to_csv(DATA_PATH, index=False)
    print(f"Saved {len(data)} synthetic isolates -> {DATA_PATH}")
    print("\nOverall % resistant per antibiotic:")
    print((data[list(ANTIBIOTICS)].mean() * 100).round(1).to_string())
