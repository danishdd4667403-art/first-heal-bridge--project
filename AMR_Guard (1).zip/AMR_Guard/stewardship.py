"""
stewardship.py  -  The "brain" that turns model predictions into an
antibiotic STEWARDSHIP recommendation.

Rule we follow (inspired by WHO AWaRe):
  1. Keep only drugs predicted to work (chance of working >= 80%).
  2. Among those, prefer Access  >  Watch  >  Reserve.
  3. Among the same category, prefer the higher chance of working.
So we don't jump to a "big gun" antibiotic when a simpler one will do.
"""
import pandas as pd

from config import (ANTIBIOTICS, AWARE_RANK, GRAM, SUSCEPTIBLE_THRESHOLD,
                    is_applicable)
from train_model import FEATURES


def predict_profile(bundle: dict, patient: dict) -> pd.DataFrame:
    """Returns a table: every applicable antibiotic + chance it will work."""
    X = pd.DataFrame([patient])[FEATURES]
    rows = []
    for abx, info in ANTIBIOTICS.items():
        if not is_applicable(abx, patient["organism"], patient["specimen"]):
            continue
        p_resistant = bundle["models"][abx].predict_proba(X)[0, 1]
        p_work = 1 - p_resistant
        if p_work >= SUSCEPTIBLE_THRESHOLD:
            status = "Likely effective"
        elif p_work >= 0.5:
            status = "Uncertain"
        else:
            status = "Likely resistant"
        rows.append({"Antibiotic": abx, "AWaRe": info["aware"], "Class": info["class"],
                     "Chance of working (%)": round(100 * p_work, 1),
                     "Prediction": status, "Pharmacist note": info["note"]})
    table = pd.DataFrame(rows)
    table["_rank"] = table["AWaRe"].map(AWARE_RANK)
    return table.sort_values(["_rank", "Chance of working (%)"],
                             ascending=[True, False]).drop(columns="_rank").reset_index(drop=True)


def recommend(profile: pd.DataFrame, threshold: float = SUSCEPTIBLE_THRESHOLD) -> dict:
    ok = profile[profile["Chance of working (%)"] >= threshold * 100]
    if len(ok):
        top = ok.iloc[0]      # already sorted Access -> Watch -> Reserve
        return {"found": True, "drug": top["Antibiotic"], "aware": top["AWaRe"],
                "chance": top["Chance of working (%)"],
                "alternatives": ok["Antibiotic"].iloc[1:3].tolist()}
    best = profile.sort_values("Chance of working (%)", ascending=False).iloc[0]
    return {"found": False, "drug": best["Antibiotic"], "aware": best["AWaRe"],
            "chance": best["Chance of working (%)"], "alternatives": []}


def risk_factors(patient: dict) -> list:
    """Plain-English list of the patient's resistance risk factors."""
    f = []
    if patient["setting"] == "ICU":
        f.append("Admitted in ICU")
    elif patient["setting"] == "Hospital ward":
        f.append("Hospital-acquired setting")
    if patient["prior_antibiotics_90d"]:
        f.append("Antibiotics taken in last 90 days")
    if patient["hospitalized_90d"]:
        f.append("Hospitalised in last 90 days")
    if patient["urinary_catheter"]:
        f.append("Urinary catheter")
    if patient["age"] >= 65:
        f.append("Age 65 or above")
    if patient["diabetes"]:
        f.append("Diabetes")
    return f


def text_report(patient: dict, profile: pd.DataFrame, rec: dict) -> str:
    lines = ["AMR-GUARD  |  Antibiotic Stewardship Decision-Support Report",
             "=" * 62,
             f"Organism : {patient['organism']} ({GRAM[patient['organism']]})",
             f"Specimen : {patient['specimen']}     Setting: {patient['setting']}",
             f"Patient  : {patient['age']} y, {patient['gender']}",
             "Risk factors: " + (", ".join(risk_factors(patient)) or "None recorded"),
             "", "Predicted susceptibility (Access -> Watch -> Reserve):"]
    for _, r in profile.iterrows():
        lines.append(f"  [{r['AWaRe']:<7}] {r['Antibiotic']:<25} "
                     f"{r['Chance of working (%)']:>5}%  {r['Prediction']}")
    lines.append("")
    if rec["found"]:
        lines.append(f"SUGGESTED EMPIRICAL OPTION: {rec['drug']} ({rec['aware']}), "
                     f"{rec['chance']}% predicted chance of working.")
        if rec["alternatives"]:
            lines.append("Alternatives: " + ", ".join(rec["alternatives"]))
    else:
        lines.append("NO option reached the safety threshold. Highest: "
                     f"{rec['drug']} ({rec['chance']}%). Consult ID specialist; await culture report.")
    lines += ["", "DISCLAIMER: Educational prototype trained on synthetic data.",
              "Not for clinical use. Final decisions rest with the treating physician."]
    return "\n".join(lines)
