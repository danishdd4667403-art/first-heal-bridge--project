"""
app.py  -  AMR-Guard web app (the working model you show the judges).

Run in the VS Code terminal:
    streamlit run app.py
A browser tab opens at http://localhost:8501
"""
import pandas as pd
import streamlit as st

from config import (ORGANISMS, SPECIMENS, SETTINGS, GRAM, ANTIBIOTICS,
                    SUSCEPTIBLE_THRESHOLD, is_applicable)
from train_model import load_or_train, load_data, build_and_save
from stewardship import predict_profile, recommend, risk_factors, text_report

st.set_page_config(page_title="AMR-Guard", page_icon="💊", layout="wide")

AWARE_COLOR = {"Access": "#2e7d32", "Watch": "#ef6c00", "Reserve": "#c62828"}

st.markdown("""
<style>
.hero {background: linear-gradient(90deg,#0b4f6c,#01baef); color:white;
       padding:18px 24px; border-radius:14px; margin-bottom:12px;}
.hero h1 {margin:0; font-size:2rem;} .hero p {margin:4px 0 0 0; opacity:.9;}
.card {border-radius:12px; padding:16px 20px; color:white; margin:6px 0;}
.pill {display:inline-block; padding:2px 10px; border-radius:20px; color:white;
       font-size:.8rem; margin-right:6px;}
</style>
<div class="hero">
  <h1>💊 AMR-Guard</h1>
  <p>AI-based antibiotic stewardship assistant &nbsp;•&nbsp; Combating Antimicrobial Resistance
  &nbsp;•&nbsp; Swasth Bharat</p>
</div>
""", unsafe_allow_html=True)
st.caption("⚠️ Educational prototype trained on synthetic data. Not for clinical use.")


@st.cache_resource(show_spinner="Loading AI models (first run trains them, ~30 s)...")
def get_bundle():
    return load_or_train()


@st.cache_data
def get_data():
    return load_data()


bundle, data = get_bundle(), get_data()

# ---------------------------------------------------------------- sidebar
with st.sidebar:
    st.header("🧾 Patient & Culture Details")
    organism = st.selectbox("Organism isolated", ORGANISMS)
    st.caption(f"{GRAM[organism]}")
    specimen = st.selectbox("Specimen", SPECIMENS)
    setting = st.selectbox("Care setting", SETTINGS)
    age = st.slider("Age (years)", 1, 95, 45)
    gender = st.radio("Gender", ["Male", "Female"], horizontal=True)
    st.markdown("**Risk factors**")
    prior = st.checkbox("Antibiotics taken in last 90 days")
    hosp = st.checkbox("Hospitalised in last 90 days")
    cath = st.checkbox("Urinary catheter")
    diab = st.checkbox("Diabetes")

patient = dict(organism=organism, specimen=specimen, setting=setting, age=age,
               gender=gender, prior_antibiotics_90d=int(prior), hospitalized_90d=int(hosp),
               urinary_catheter=int(cath), diabetes=int(diab))

tab1, tab2, tab3, tab4 = st.tabs(["🧪 Predict & Recommend", "📊 AMR Surveillance Dashboard",
                                  "🤖 Model Performance", "ℹ️ About"])

# ---------------------------------------------------------------- tab 1
with tab1:
    profile = predict_profile(bundle, patient)
    rec = recommend(profile)

    c1, c2, c3 = st.columns(3)
    c1.metric("Antibiotics evaluated", len(profile))
    c2.metric("Likely effective (≥80%)", int((profile["Prediction"] == "Likely effective").sum()))
    c3.metric("Risk factors present", len(risk_factors(patient)))

    if rec["found"]:
        color = AWARE_COLOR[rec["aware"]]
        alt = ", ".join(rec["alternatives"]) or "—"
        st.markdown(f"""<div class="card" style="background:{color}">
            <h3 style="margin:0">✅ Suggested empirical option: {rec['drug']}</h3>
            WHO AWaRe: <b>{rec['aware']}</b> &nbsp;|&nbsp; Predicted chance of working:
            <b>{rec['chance']}%</b><br>Alternatives: {alt}</div>""", unsafe_allow_html=True)
    else:
        st.markdown(f"""<div class="card" style="background:#6a1b9a">
            <h3 style="margin:0">🚨 High resistance risk — no option reached {int(SUSCEPTIBLE_THRESHOLD*100)}%</h3>
            Best available: <b>{rec['drug']}</b> ({rec['chance']}%). Refer to Infectious Disease
            specialist and wait for the culture sensitivity report.</div>""", unsafe_allow_html=True)

    rf = risk_factors(patient)
    if rf:
        st.write("**Resistance risk factors:** " + " • ".join(rf))

    st.subheader("Predicted antibiogram (sorted Access → Watch → Reserve)")
    st.dataframe(
        profile, use_container_width=True, hide_index=True,
        column_config={"Chance of working (%)": st.column_config.ProgressColumn(
            "Chance of working (%)", min_value=0, max_value=100, format="%.1f%%")})

    st.bar_chart(profile.set_index("Antibiotic")["Chance of working (%)"])

    st.download_button("⬇️ Download stewardship report (.txt)",
                       text_report(patient, profile, rec), file_name="amr_guard_report.txt")

    not_used = [a for a in ANTIBIOTICS if not is_applicable(a, organism, specimen)]
    if not_used:
        st.caption("Not applicable for this organism/specimen: " + ", ".join(not_used))

# ---------------------------------------------------------------- tab 2
with tab2:
    st.subheader("Hospital antibiogram — % resistant (synthetic surveillance data)")
    abx_cols = list(ANTIBIOTICS)
    table = (data.groupby("organism")[abx_cols].mean() * 100).round(1)
    st.dataframe(table.T, use_container_width=True,
                 column_config={o: st.column_config.ProgressColumn(
                     o, min_value=0, max_value=100, format="%.1f%%") for o in table.index})

    st.subheader("How care setting changes resistance")
    org_pick = st.selectbox("Choose organism", ORGANISMS, key="dash_org")
    sub = data[data["organism"] == org_pick]
    usable = [a for a in abx_cols if sub[a].notna().any()]
    by_setting = (sub.groupby("setting")[usable].mean() * 100).round(1).reindex(SETTINGS)
    st.bar_chart(by_setting.T)
    st.caption("Notice: resistance rises from Community → Ward → ICU. "
               "This is the pattern the AI learns.")

    st.subheader("Effect of prior antibiotic use")
    prior_tbl = (sub.groupby("prior_antibiotics_90d")[usable].mean() * 100).round(1)
    prior_tbl.index = prior_tbl.index.map({0: "No prior antibiotics", 1: "Prior antibiotics (90 d)"})
    st.bar_chart(prior_tbl.T)
    st.write(f"Dataset: **{len(data):,} isolates**")

# ---------------------------------------------------------------- tab 3
with tab3:
    st.subheader("One model per antibiotic")
    st.write("For each drug we trained **Logistic Regression** and **Random Forest** and "
             "kept the one with the higher ROC-AUC on 25% held-out test data.")
    st.dataframe(bundle["metrics"], use_container_width=True, hide_index=True)
    st.caption("ROC-AUC: 0.5 = random guessing, 1.0 = perfect. Very rare resistances "
               "(e.g. Vancomycin ~1%) are hard to learn — an honest limitation.")
    st.caption(f"Trained on {bundle['n_isolates']:,} isolates at {bundle['trained_at']}")
    if st.button("🔁 Re-generate data & retrain"):
        build_and_save()
        st.cache_resource.clear(); st.cache_data.clear()
        st.rerun()

# ---------------------------------------------------------------- tab 4
with tab4:
    st.markdown("""
### Problem
Doctors often prescribe antibiotics **before** the lab culture report arrives (48–72 h).
Guessing wrong → treatment failure. Always choosing the strongest drug → drives **antimicrobial
resistance (AMR)**, one of WHO's top global health threats, with India among the most affected countries.

### Our solution
AMR-Guard predicts, from patient risk factors, **which antibiotics are likely to work**, and then
recommends the **narrowest safe option** using the **WHO AWaRe** framework:
<span class="pill" style="background:#2e7d32">Access</span>
<span class="pill" style="background:#ef6c00">Watch</span>
<span class="pill" style="background:#c62828">Reserve</span>

### Pipeline
Patient data → AI models (one per antibiotic) → susceptibility % → AWaRe-based stewardship
rule → recommendation + report.

### Role of the pharmacist
Antimicrobial stewardship programmes rely on pharmacists to review prescriptions. AMR-Guard is a
decision-support tool for that review — it **supports**, never replaces, clinical judgement.
""", unsafe_allow_html=True)
