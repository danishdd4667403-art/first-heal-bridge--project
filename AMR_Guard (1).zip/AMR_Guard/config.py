"""
config.py  -  All the "medical knowledge" constants used by the project.

Keeping these in ONE file means you can change a number here and the
whole project (data, model, app) updates automatically.
"""

# ---------------------------------------------------------------------------
# 1. Bacteria (organisms) we handle and how common each one is in our data
# ---------------------------------------------------------------------------
ORGANISMS = [
    "Escherichia coli",
    "Klebsiella pneumoniae",
    "Pseudomonas aeruginosa",
    "Staphylococcus aureus",
]
ORGANISM_PREVALENCE = [0.45, 0.25, 0.12, 0.18]   # must add up to 1

# Gram stain (useful to show in the app)
GRAM = {
    "Escherichia coli": "Gram-negative",
    "Klebsiella pneumoniae": "Gram-negative",
    "Pseudomonas aeruginosa": "Gram-negative",
    "Staphylococcus aureus": "Gram-positive",
}

# ---------------------------------------------------------------------------
# 2. Sample type and patient care setting
# ---------------------------------------------------------------------------
SPECIMENS = ["Urine", "Blood", "Sputum", "Wound/Pus"]

# Where each organism is usually isolated from (probabilities per specimen)
SPECIMEN_BY_ORGANISM = {
    "Escherichia coli":       [0.70, 0.15, 0.05, 0.10],
    "Klebsiella pneumoniae":  [0.40, 0.20, 0.30, 0.10],
    "Pseudomonas aeruginosa": [0.20, 0.15, 0.35, 0.30],
    "Staphylococcus aureus":  [0.05, 0.25, 0.15, 0.55],
}

SETTINGS = ["Community (OPD)", "Hospital ward", "ICU"]
SETTING_PREVALENCE = [0.50, 0.35, 0.15]

# ---------------------------------------------------------------------------
# 3. Antibiotics + WHO AWaRe category
#    Access  = first choice, low resistance risk
#    Watch   = higher resistance potential, use carefully
#    Reserve = last-resort, protect these!
# ---------------------------------------------------------------------------
ANTIBIOTICS = {
    "Amoxicillin-clavulanate": {"aware": "Access",  "class": "Penicillin + beta-lactamase inhibitor",
                                "note": "Oral Access option; check penicillin allergy."},
    "Gentamicin":              {"aware": "Access",  "class": "Aminoglycoside",
                                "note": "Monitor kidney function and hearing."},
    "Nitrofurantoin":          {"aware": "Access",  "class": "Nitrofuran",
                                "note": "Only for lower urinary tract infection (cystitis); not for blood infections."},
    "Co-trimoxazole":          {"aware": "Access",  "class": "Sulfonamide + trimethoprim",
                                "note": "Oral Access option; check sulfa allergy."},
    "Ciprofloxacin":           {"aware": "Watch",   "class": "Fluoroquinolone",
                                "note": "Avoid for mild infections when Access options work."},
    "Ceftriaxone":             {"aware": "Watch",   "class": "3rd-generation cephalosporin",
                                "note": "Heavy use drives ESBL resistance."},
    "Meropenem":               {"aware": "Watch",   "class": "Carbapenem",
                                "note": "Preserve for severe / ESBL infections."},
    "Vancomycin":              {"aware": "Watch",   "class": "Glycopeptide",
                                "note": "MRSA option; needs blood-level (TDM) monitoring."},
    "Linezolid":               {"aware": "Reserve", "class": "Oxazolidinone",
                                "note": "Last-resort for resistant Gram-positive bacteria."},
    "Colistin":                {"aware": "Reserve", "class": "Polymyxin",
                                "note": "Last-resort for Gram-negatives; can harm kidneys."},
}
AWARE_RANK = {"Access": 0, "Watch": 1, "Reserve": 2}

# ---------------------------------------------------------------------------
# 4. Baseline resistance rates (fraction resistant) for each bug-drug pair.
#    ILLUSTRATIVE values loosely inspired by trends reported in Indian
#    surveillance (e.g. ICMR-AMRSN).  They are NOT official figures.
#    If a drug is missing for an organism, it is "not applicable"
#    (the drug does not work on that bug by nature, or is not used for it).
# ---------------------------------------------------------------------------
BASE_RESISTANCE = {
    "Escherichia coli": {
        "Amoxicillin-clavulanate": 0.60, "Gentamicin": 0.35, "Nitrofurantoin": 0.15,
        "Co-trimoxazole": 0.55, "Ciprofloxacin": 0.70, "Ceftriaxone": 0.65,
        "Meropenem": 0.12, "Colistin": 0.03,
    },
    "Klebsiella pneumoniae": {
        "Amoxicillin-clavulanate": 0.70, "Gentamicin": 0.45, "Co-trimoxazole": 0.55,
        "Ciprofloxacin": 0.65, "Ceftriaxone": 0.70, "Meropenem": 0.40, "Colistin": 0.08,
    },
    "Pseudomonas aeruginosa": {
        "Gentamicin": 0.35, "Ciprofloxacin": 0.40, "Meropenem": 0.35, "Colistin": 0.05,
    },
    "Staphylococcus aureus": {
        "Gentamicin": 0.25, "Co-trimoxazole": 0.40, "Ciprofloxacin": 0.60,
        "Vancomycin": 0.01, "Linezolid": 0.01,
    },
}

# ---------------------------------------------------------------------------
# 5. Model input columns
# ---------------------------------------------------------------------------
CATEGORICAL_FEATURES = ["organism", "specimen", "setting", "gender"]
NUMERIC_FEATURES = ["age", "prior_antibiotics_90d", "hospitalized_90d",
                    "urinary_catheter", "diabetes"]

# A drug is called "likely effective" if predicted chance of working >= this
SUSCEPTIBLE_THRESHOLD = 0.80

DATA_PATH = "data/amr_isolates.csv"
MODEL_PATH = "models/amr_bundle.joblib"


def is_applicable(antibiotic: str, organism: str, specimen: str) -> bool:
    """Can this antibiotic sensibly be considered for this bug + sample?"""
    if antibiotic not in BASE_RESISTANCE[organism]:
        return False
    if antibiotic == "Nitrofurantoin" and specimen != "Urine":
        return False
    return True
