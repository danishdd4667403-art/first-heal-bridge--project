"""
demo_cli.py  -  Backup demo that runs in the terminal (no browser needed).
Useful if the web app has any trouble on presentation day.

Run:   python demo_cli.py
"""
from config import ORGANISMS, SPECIMENS, SETTINGS
from train_model import load_or_train
from stewardship import predict_profile, recommend, text_report


def pick(title, options):
    print(f"\n{title}")
    for i, o in enumerate(options, 1):
        print(f"  {i}. {o}")
    while True:
        choice = input("Enter number: ").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(options):
            return options[int(choice) - 1]
        print("  Please type a valid number.")


def yes_no(question):
    return int(input(f"{question} (y/n): ").strip().lower().startswith("y"))


def main():
    print("=== AMR-Guard: terminal demo ===")
    bundle = load_or_train()
    while True:
        patient = {
            "organism": pick("Organism isolated:", ORGANISMS),
            "specimen": pick("Specimen:", SPECIMENS),
            "setting": pick("Care setting:", SETTINGS),
            "age": int(input("\nAge in years: ") or 40),
            "gender": pick("Gender:", ["Male", "Female"]),
            "prior_antibiotics_90d": yes_no("Antibiotics in last 90 days?"),
            "hospitalized_90d": yes_no("Hospitalised in last 90 days?"),
            "urinary_catheter": yes_no("Urinary catheter?"),
            "diabetes": yes_no("Diabetes?"),
        }
        profile = predict_profile(bundle, patient)
        print("\n" + text_report(patient, profile, recommend(profile)))
        if not yes_no("\nAnalyse another patient?"):
            break


if __name__ == "__main__":
    main()
