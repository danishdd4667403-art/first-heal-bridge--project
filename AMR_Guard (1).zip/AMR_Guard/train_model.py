"""
train_model.py  -  Trains one AI model PER antibiotic.

Each model answers:  "Given this patient and this bacterium, what is the
chance the bacterium is RESISTANT to this antibiotic?"

We try two algorithms and keep whichever scores better:
  * Logistic Regression  (simple, explainable)
  * Random Forest        (many decision trees voting together)

Score used: ROC-AUC  (0.5 = guessing, 1.0 = perfect)

Run:   python train_model.py
"""
import os
from datetime import datetime

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

from config import (ANTIBIOTICS, CATEGORICAL_FEATURES, NUMERIC_FEATURES,
                    DATA_PATH, MODEL_PATH)
from generate_data import generate_dataset

FEATURES = CATEGORICAL_FEATURES + NUMERIC_FEATURES


def make_pipeline(algorithm: str) -> Pipeline:
    """Pre-processing (text -> numbers) + the classifier, glued together."""
    preprocess = ColumnTransformer([
        ("categories", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL_FEATURES),
        ("numbers", "passthrough", NUMERIC_FEATURES),
    ])
    if algorithm == "Logistic Regression":
        model = LogisticRegression(max_iter=2000)
    else:
        model = RandomForestClassifier(n_estimators=200, min_samples_leaf=10,
                                       random_state=42, n_jobs=-1)
    return Pipeline([("preprocess", preprocess), ("model", model)])


def train_all(df: pd.DataFrame) -> dict:
    models, metrics = {}, []

    for abx in ANTIBIOTICS:
        rows = df[df[abx].notna()]              # only isolates where this drug applies
        X, y = rows[FEATURES], rows[abx].astype(int)

        X_tr, X_te, y_tr, y_te = train_test_split(
            X, y, test_size=0.25, random_state=42,
            stratify=y if y.nunique() > 1 and y.value_counts().min() >= 2 else None)

        best = None
        for algo in ["Logistic Regression", "Random Forest"]:
            pipe = make_pipeline(algo).fit(X_tr, y_tr)
            prob = pipe.predict_proba(X_te)[:, 1]
            auc = roc_auc_score(y_te, prob) if y_te.nunique() > 1 else np.nan
            acc = accuracy_score(y_te, (prob >= 0.5).astype(int))
            score = -1 if np.isnan(auc) else auc
            if best is None or score > best["score"]:
                best = {"pipe": pipe, "algo": algo, "auc": auc, "acc": acc, "score": score}

        # refit the winner on ALL data for the final model
        final = make_pipeline(best["algo"]).fit(X, y)
        models[abx] = final
        metrics.append({
            "Antibiotic": abx,
            "AWaRe": ANTIBIOTICS[abx]["aware"],
            "Best model": best["algo"],
            "ROC-AUC": round(best["auc"], 3) if not np.isnan(best["auc"]) else None,
            "Accuracy": round(best["acc"], 3),
            "Isolates used": len(rows),
            "% Resistant": round(100 * y.mean(), 1),
        })
        print(f"  {abx:<25} {best['algo']:<20} AUC={metrics[-1]['ROC-AUC']}")

    return {"models": models, "metrics": pd.DataFrame(metrics),
            "n_isolates": len(df), "trained_at": datetime.now().strftime("%Y-%m-%d %H:%M")}


def load_or_train() -> dict:
    """Used by the app: load saved models, or build everything from scratch."""
    if os.path.exists(MODEL_PATH):
        return joblib.load(MODEL_PATH)
    return build_and_save()


def load_data() -> pd.DataFrame:
    if not os.path.exists(DATA_PATH):
        os.makedirs("data", exist_ok=True)
        generate_dataset().to_csv(DATA_PATH, index=False)
    return pd.read_csv(DATA_PATH)


def build_and_save() -> dict:
    df = load_data()
    print(f"Training on {len(df)} isolates...")
    bundle = train_all(df)
    os.makedirs("models", exist_ok=True)
    joblib.dump(bundle, MODEL_PATH)
    print(f"Saved models -> {MODEL_PATH}")
    return bundle


if __name__ == "__main__":
    b = build_and_save()
    print("\n", b["metrics"].to_string(index=False))
